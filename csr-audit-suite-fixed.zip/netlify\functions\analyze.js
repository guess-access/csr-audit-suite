// netlify/functions/analyze.js
//
// Takes a call transcript (plain text, produced by transcribe.js) and scores
// it against the CSR Fundamentals audit criteria using Claude. The Anthropic
// API key lives here, server-side, and is never sent to the browser.
//
// Required environment variable (set in Netlify: Site settings > Environment
// variables): ANTHROPIC_API_KEY

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'ANTHROPIC_API_KEY is not set. Add it in Netlify: Site settings > Environment variables, then redeploy.',
      }),
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (err) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { transcript, agentName, callDate } = payload;
  if (!transcript || !transcript.trim()) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing "transcript" in request body' }) };
  }

  const prompt = `Analyze this dealership customer service call transcript against the CSR Fundamentals audit criteria.

Agent: ${agentName || 'Unknown'}
Call date: ${callDate || 'Unknown'}

Transcript:
"""
${transcript}
"""

Evaluate and score these metrics:

SECTION 1 - Call Flow Procedure (20 pts):
1. Agent announced dealership name (10 pts)
2. Agent introduced themselves by name (10 pts)

SECTION 2 - Body of the Call (24 pts):
3. Asked reason for transfer (8 pts)
4. Asked for customer name (8 pts)
5. Introduced customer to department (8 pts)

SECTION 3 - System Process Accuracy (21 pts):
6. Warm transfer protocol correct (8 pts)
7. Data entered accurately (5 pts)
8. Correct disposition selected (8 pts)

SECTION 4 - Call Management Skills (35 pts):
9. Hold procedure / expectation setting (5 pts)
10. Communication clarity (5 pts)
11. Empathy shown (5 pts)
12. Active listening (5 pts)
13. Tone of voice (5 pts)
14. Efficiency (5 pts)
15. Confidence (5 pts)

SECTION 5 - Zero Tolerance (Auto-fail):
16. No rudeness/profanity
17. No service booking failures
18. No intentional disconnects

Provide analysis in this JSON format:
{
  "overall_score": number 0-100,
  "metrics": [
    {"metric": "name", "score_earned": number, "score_possible": number, "status": "pass/fail/partial", "observation": "specific observation"}
  ],
  "strengths": ["strength1", "strength2"],
  "opportunities": ["area1", "area2"],
  "concerns": [],
  "recommended_actions": ["action1", "action2"],
  "coaching_notes": "detailed coaching feedback"
}

Respond ONLY with valid JSON, no other text.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      const message = data?.error?.message || 'Claude API request failed';
      return { statusCode: response.status, headers, body: JSON.stringify({ error: message }) };
    }

    const textContent = data?.content?.[0]?.text || '';
    const jsonMatch = textContent.match(/\{[\s\S]*\}/);

    if (!jsonMatch) {
      return { statusCode: 502, headers, body: JSON.stringify({ error: 'Claude did not return a parseable analysis' }) };
    }

    const analysis = JSON.parse(jsonMatch[0]);
    return { statusCode: 200, headers, body: JSON.stringify({ analysis }) };
  } catch (err) {
    return { statusCode: 502, headers, body: JSON.stringify({ error: `Analysis request failed: ${err.message}` }) };
  }
};
